from setuptools import setup, find_packages

setup(
    name="viz3d",
    version="0.1.0",
    description="Простая библиотека для интерактивной 3D-визуализации функций в браузере",
    packages=find_packages(),
    install_requires=[
        "numpy>=1.20",
        "flask>=2.0",
    ],
    python_requires=">=3.8",
)
