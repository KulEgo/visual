"""
viz3d — простая библиотека для 3D-визуализации математических функций.

Пример использования:
    from viz3d import plot

    # Функция 2 переменных: z = f(x, y)
    plot(lambda x, y: x**2 + y**2)

    # Функция 3 переменных (параметрическая поверхность): (x, y, z) = f(u, v)
    plot(lambda u, v: (np.cos(u)*np.sin(v), np.sin(u)*np.sin(v), np.cos(v)))
"""

from .visualizer import plot

__all__ = ["plot"]
__version__ = "0.1.0"
